<?php

$_CONFIG['host'] = "localhost";
$_CONFIG['user'] = "root";
$_CONFIG['pass'] = "root";
$_CONFIG['dbname'] = "portfolio";


//DB Connect
$conn = mysqli_connect($_CONFIG['host'], $_CONFIG['user'], $_CONFIG['pass']) or die('Impossibile stabilire una connessione');
mysqli_select_db($conn, $_CONFIG['dbname']);


date_default_timezone_set("Asia/Calcutta");
