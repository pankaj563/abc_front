<?php
include('config.php');

        
?>
<!DOCTYPE html>
<html lang="en" data-theme="system">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0 shrink-to-fit=no">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>Neon</title>
		<link rel="preconnect" href="https://neon.gbjsolution.com">
		<script>
    if(typeof(Storage) !== 'undefined') {
        let themeMode = document.documentElement.getAttribute('data-theme');
        if (themeMode !== null && themeMode === 'system') {
            setSysPrefColor();
        }
        const theme = localStorage.getItem('selected-theme');
        if (theme == 'light') {
            setColorScheme('light');
        }
        else if (theme == 'dark') {
            setColorScheme('dark');
        }
    }
    function setSysPrefColor() {
        if(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches){
            setColorScheme('dark');
        }
        window.matchMedia('(prefers-color-scheme: dark)').addListener(e => {
            if (e.matches) {
                setColorScheme('dark');
            } else {
                setColorScheme('light');
            }
        });
    }
    function setColorScheme(scheme) {
        if (scheme=='dark') {
            document.documentElement.setAttribute('data-theme', 'dark');
        } else {
            document.documentElement.removeAttribute('data-theme');
        }
    }
</script>        
        <link href="/blog/assets/css/style.min.css?v=7ce521441b" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tiny-slider/2.9.4/tiny-slider.css">
		
   
    
    
	</head>
	<body class="home-template" data-nav="normal">
		<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="global-icons" style="display:none">
    <symbol id="i-search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" d="M0 0h24v24H0z"/>
    <path d="M18.031 16.617l4.283 4.282-1.415 1.415-4.282-4.283A8.96 8.96 0 0 1 11 20c-4.968 0-9-4.032-9-9s4.032-9 9-9 9 4.032 9 9a8.96 8.96 0 0 1-1.969 5.617zm-2.006-.742A6.977 6.977 0 0 0 18 11c0-3.868-3.133-7-7-7-3.868 0-7 3.132-7 7 0 3.867 3.132 7 7 7a6.977 6.977 0 0 0 4.875-1.975l.15-.15z"/></symbol>
    <symbol id="i-moon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" d="M0 0h24v24H0z"/><path d="M10 7a7 7 0 0 0 12 4.9v.1c0 5.523-4.477 10-10 10S2 17.523 2 12 6.477 2 12 2h.1A6.979 6.979 0 0 0 10 7zm-6 5a8 8 0 0 0 15.062 3.762A9 9 0 0 1 8.238 4.938 7.999 7.999 0 0 0 4 12z"/></symbol>
    <symbol id="i-sun" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" d="M0 0h24v24H0z"/><path d="M12 18a6 6 0 1 1 0-12 6 6 0 0 1 0 12zm0-2a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM11 1h2v3h-2V1zm0 19h2v3h-2v-3zM3.515 4.929l1.414-1.414L7.05 5.636 5.636 7.05 3.515 4.93zM16.95 18.364l1.414-1.414 2.121 2.121-1.414 1.414-2.121-2.121zm2.121-14.85l1.414 1.415-2.121 2.121-1.414-1.414 2.121-2.121zM5.636 16.95l1.414 1.414-2.121 2.121-1.414-1.414 2.121-2.121zM23 11v2h-3v-2h3zM4 11v2H1v-2h3z"/></symbol>
    <symbol id="i-twitter" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" d="M0 0h24v24H0z"/><path d="M22.162 5.656a8.384 8.384 0 0 1-2.402.658A4.196 4.196 0 0 0 21.6 4c-.82.488-1.719.83-2.656 1.015a4.182 4.182 0 0 0-7.126 3.814 11.874 11.874 0 0 1-8.62-4.37 4.168 4.168 0 0 0-.566 2.103c0 1.45.738 2.731 1.86 3.481a4.168 4.168 0 0 1-1.894-.523v.052a4.185 4.185 0 0 0 3.355 4.101 4.21 4.21 0 0 1-1.89.072A4.185 4.185 0 0 0 7.97 16.65a8.394 8.394 0 0 1-6.191 1.732 11.83 11.83 0 0 0 6.41 1.88c7.693 0 11.9-6.373 11.9-11.9 0-.18-.005-.362-.013-.54a8.496 8.496 0 0 0 2.087-2.165z"/></symbol>
    <symbol id="i-facebook" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" d="M0 0h24v24H0z"/><path d="M14 13.5h2.5l1-4H14v-2c0-1.03 0-2 2-2h1.5V2.14c-.326-.043-1.557-.14-2.857-.14C11.928 2 10 3.657 10 6.7v2.8H7v4h3V22h4v-8.5z"/></symbol>
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path fill="none" d="M0 0h24v24H0z"/><path d="M4 22a8 8 0 1 1 16 0H4zm8-9c-3.315 0-6-2.685-6-6s2.685-6 6-6 6 2.685 6 6-2.685 6-6 6z"/></svg>
    <svg id="i-user" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" d="M0 0h24v24H0z"/><path d="M4 22a8 8 0 1 1 16 0H4zm9-5.917V20h4.659A6.009 6.009 0 0 0 13 16.083zM11 20v-3.917A6.009 6.009 0 0 0 6.341 20H11zm1-7c-3.315 0-6-2.685-6-6s2.685-6 6-6 6 2.685 6 6-2.685 6-6 6zm0-2c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4z"/></svg>
    <symbol xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" d="M0 0h24v24H0z"/><path d="M4 22a8 8 0 1 1 16 0h-2a6 6 0 1 0-12 0H4zm8-9c-3.315 0-6-2.685-6-6s2.685-6 6-6 6 2.685 6 6-2.685 6-6 6zm0-2c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4z"/></symbol>
    <symbol id="i-calendar" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" d="M0 0h24v24H0z"/><path d="M17 3h4a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h4V1h2v2h6V1h2v2zm3 8H4v8h16v-8zm-5-6H9v2H7V5H4v4h16V5h-3v2h-2V5zm-9 8h2v2H6v-2zm5 0h2v2h-2v-2zm5 0h2v2h-2v-2z"/></symbol>
    <symbol id="i-clock" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" d="M0 0h24v24H0z"/><path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm0-2a8 8 0 1 0 0-16 8 8 0 0 0 0 16zm1-8h4v2h-6V7h2v5z"/></symbol>
    <symbol id="i-map-pin" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" d="M0 0h24v24H0z"/><path d="M12 23.728l-6.364-6.364a9 9 0 1 1 12.728 0L12 23.728zm4.95-7.778a7 7 0 1 0-9.9 0L12 20.9l4.95-4.95zM12 13a2 2 0 1 1 0-4 2 2 0 0 1 0 4z"/></symbol>
    <symbol id="i-link" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" d="M0 0h24v24H0z"/><path d="M18.364 15.536L16.95 14.12l1.414-1.414a5 5 0 1 0-7.071-7.071L9.879 7.05 8.464 5.636 9.88 4.222a7 7 0 0 1 9.9 9.9l-1.415 1.414zm-2.828 2.828l-1.415 1.414a7 7 0 0 1-9.9-9.9l1.415-1.414L7.05 9.88l-1.414 1.414a5 5 0 1 0 7.071 7.071l1.414-1.414 1.415 1.414zm-.708-10.607l1.415 1.415-7.071 7.07-1.415-1.414 7.071-7.07z"/></symbol>
    <symbol id="i-close" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" d="M0 0h24v24H0z"/><path d="M12 10.586l4.95-4.95 1.414 1.414-4.95 4.95 4.95 4.95-1.414 1.414-4.95-4.95-4.95 4.95-1.414-1.414 4.95-4.95-4.95-4.95L7.05 5.636z"/></symbol>
    <symbol id="i-arrow-left" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" d="M0 0h24v24H0z"/><path d="M7.828 11H20v2H7.828l5.364 5.364-1.414 1.414L4 12l7.778-7.778 1.414 1.414z"/></symbol>
    <symbol id="i-arrow-right"  xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" d="M0 0h24v24H0z"/><path d="M16.172 11l-5.364-5.364 1.414-1.414L20 12l-7.778 7.778-1.414-1.414L16.172 13H4v-2z"/></symbol>
</svg>		<div class="site-wrap">
		<header class="site-header">
    <div class="container">
        <div class="header-inner flex justify-space-between">
            <div class="header-logo">
                <a href="https://neon.gbjsolution.com" class="logo-image theme-light-logo">
    <img src="https://neon.gbjsolution.com/content/images/2022/12/logo-dark.svg" alt="Neon">
</a>
<a href="https://neon.gbjsolution.com" class="logo-image theme-dark-logo">
    <img src="https://neon.gbjsolution.com/content/images/2022/12/logo-light.svg" alt="Neon">
</a>
            </div>
            <input id="mobile-menu-toggle" class="mobile-menu-checkbox" type="checkbox">
            <label for="mobile-menu-toggle" class="mobile-menu-icon" aria-label="menu toggle button">
                <span class="line"></span>
                <span class="line"></span>
                <span class="line"></span>
                <span class="sr-only">Menu toggle button</span>
            </label>
            <nav class="nav-wrap flex" role="navigation" aria-label="main navigation">
    <ul class="nav-item-container nav-left no-style-list flex" role="menu">
        <li class="nav-item" role="menuitem">
            <a href="/features/" class="nav-link">Share Market</a>
        </li>
        <li class="nav-item" role="menuitem">
            <a href="/style-guide/" class="nav-link">Automobile</a>
        </li>
        <li class="nav-item" role="menuitem">
            <a href="/tags/" class="nav-link">Bollywood</a>
        </li>
        <li class="nav-item" role="menuitem">
            <a href="/authors/" class="nav-link">Books</a>
        </li>
        <!-- <li class="nav-item has-dropdown" role="menuitem">
            <a href="#" class="nav-link more-link">More<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path fill="none" d="M0 0h24v24H0z"/><path d="M12 13.172l4.95-4.95 1.414 1.414L12 16 5.636 9.636 7.05 8.222z"/></svg></a>
            <ul class="no-style-list dropdown-menu">
            <li class="nav-item" role="menuitem">
                <a href="/home-2/" class="nav-link">Home post vertical</a>
            </li>
            <li class="nav-item" role="menuitem">
                <a href="/home-3/" class="nav-link">Home post masonry</a>
            </li>
            <li class="nav-item" role="menuitem">
                <a href="/never-let-your-memories-be-greater-than-your-dreams/" class="nav-link">Post fullwidth</a>
            </li>
            <li class="nav-item" role="menuitem">
                <a href="/i-do-not-stick-to-rules-when-cooking-i-rely-on-my-imagination/" class="nav-link">Post no sidebar</a>
            </li>
            <li class="nav-item" role="menuitem">
                <a href="/stop-worrying-about-the-potholes-in-the-road-and-enjoy-the-journey/" class="nav-link">Post cover auto height</a>
            </li>
            <li class="nav-item" role="menuitem">
                <a href="/self-observation-is-the-first-step-of-inner-unfolding/" class="nav-link">Post with TOC</a>
            </li>
            <li class="nav-item" role="menuitem">
                <a href="/tags-2/" class="nav-link">Tag style two</a>
            </li>
            <li class="nav-item" role="menuitem">
                <a href="/author-2/" class="nav-link">Author style two</a>
            </li>
            <li class="nav-item" role="menuitem">
                <a href="/author-3/" class="nav-link">Author style three</a>
            </li>
            <li class="nav-item" role="menuitem">
                <a href="/yearly-archive/" class="nav-link">Yearly archive</a>
            </li>
            <li class="nav-item" role="menuitem">
                <a href="/monthly-archive/" class="nav-link">Monthly archive</a>
            </li>
            <li class="nav-item" role="menuitem">
                <a href="/contact/" class="nav-link">Contact</a>
            </li>
            <li class="nav-item" role="menuitem">
                <a href="https://gbjsolution.com/documentation/ghost-themes/neon/" class="nav-link">Documentation</a>
            </li>
        </ul>
        </li> -->
    </ul>
    <div class="nav-center icon-items-wrap flex">
        <button href="javascript:;" class="nav-icon search-icon flex" data-ghost-search>
            <span><svg><use xlink:href="#i-search"></use></svg></span>
        </button>
        <button href="javascript:;" class="nav-icon theme-icon flex js-toggle-dark-light" aria-label="Toggle theme">
            <div class="toggle-mode flex">
                <div class="light"><svg><use xlink:href="#i-sun"></use></svg></div>
                <span class="dark"><svg><use xlink:href="#i-moon"></use></svg></span>
            </div>
        </button>
    </div>
    <!-- <ul class="nav-item-container nav-right no-style-list flex">
        <li class="nav-item" role="menuitem">
            <a href="https://neon.gbjsolution.com/signin/" class="nav-link">Sign in</a>
        </li>
        <li class="nav-item" role="menuitem">
            <a href="/membership/" class="btn btn-sm">Become member</a>
        </li>
    </ul> -->
</nav>

        </div>
    </div>
</header>		<div class="container cover home-intro-one">
    <!-- <div class="row ">
        <div class="col-md-12">
            <div class="featured-slider"> -->
                <!-- <article class="hero-post-card">
                    <div class="row">
                        <div class="col-md-7">
                            <div class="post-img-container">
                                <a href="/never-let-your-memories-be-greater-than-your-dreams/" class="post-img-wrap">
                                    <img loading="lazy" srcset="https://images.unsplash.com/photo-1513436539083-9d2127e742f1?crop&#x3D;entropy&amp;cs&#x3D;tinysrgb&amp;fit&#x3D;max&amp;fm&#x3D;jpg&amp;ixid&#x3D;MnwxMTc3M3wwfDF8c2VhcmNofDI5fHxkcmVhbXxlbnwwfHx8fDE2NzE0MzA3MTU&amp;ixlib&#x3D;rb-4.0.3&amp;q&#x3D;80&amp;w&#x3D;300 300w,
                                            https://images.unsplash.com/photo-1513436539083-9d2127e742f1?crop&#x3D;entropy&amp;cs&#x3D;tinysrgb&amp;fit&#x3D;max&amp;fm&#x3D;jpg&amp;ixid&#x3D;MnwxMTc3M3wwfDF8c2VhcmNofDI5fHxkcmVhbXxlbnwwfHx8fDE2NzE0MzA3MTU&amp;ixlib&#x3D;rb-4.0.3&amp;q&#x3D;80&amp;w&#x3D;600 600w"
                                        sizes="(max-width: 472px) 400px, (max-width: 767px) 600px, (min-width: 768px) 400px, 400px"
                                        src="https://images.unsplash.com/photo-1513436539083-9d2127e742f1?crop&#x3D;entropy&amp;cs&#x3D;tinysrgb&amp;fit&#x3D;max&amp;fm&#x3D;jpg&amp;ixid&#x3D;MnwxMTc3M3wwfDF8c2VhcmNofDI5fHxkcmVhbXxlbnwwfHx8fDE2NzE0MzA3MTU&amp;ixlib&#x3D;rb-4.0.3&amp;q&#x3D;80&amp;w&#x3D;300" alt="Never let your memories be greater than your dreams">
                                </a>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="post-info-wrap">
                                <div class="tag-list">
                                    <a href="/tag/travel/"><span class="tag-accent" style="background: #E10689;"></span>Travel</a>
                                </div>
                                <h2 class="post-title h1">
                                    <a href="/never-let-your-memories-be-greater-than-your-dreams/">Never let your memories be greater than your dreams</a>
                                </h2>
                                <div class="post-excerpt">
                                    Before long the searchlight discovered some distance away a schooner with all sails set, apparently the same vessel which had been noticed earlier in the evening. The wind had by this time backed to the east, and there was a shudder amongst the watchers on
                                </div>
                                <div class="post-meta text-s">
                                    <time class="post-date" datetime="2022-05-02">
                                        <svg><use xlink:href="#i-calendar"></use></svg>May 2, 2022
                                    </time>
                                    <span class="read-time">
                                        <svg><use xlink:href="#i-clock"></use></svg>4 min read
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </article> -->
                <!-- <article class="hero-post-card">
                    <div class="row">
                        <div class="col-md-7">
                            <div class="post-img-container">
                                <a href="/self-observation-is-the-first-step-of-inner-unfolding/" class="post-img-wrap">
                                    <img loading="lazy" srcset="https://images.unsplash.com/photo-1574102289244-69b848408915?crop&#x3D;entropy&amp;cs&#x3D;tinysrgb&amp;fit&#x3D;max&amp;fm&#x3D;jpg&amp;ixid&#x3D;MnwxMTc3M3wwfDF8c2VhcmNofDExfHxvYnNlcnZhdGlvbnxlbnwwfHx8fDE2NzE0MzExODM&amp;ixlib&#x3D;rb-4.0.3&amp;q&#x3D;80&amp;w&#x3D;300 300w,
                                            https://images.unsplash.com/photo-1574102289244-69b848408915?crop&#x3D;entropy&amp;cs&#x3D;tinysrgb&amp;fit&#x3D;max&amp;fm&#x3D;jpg&amp;ixid&#x3D;MnwxMTc3M3wwfDF8c2VhcmNofDExfHxvYnNlcnZhdGlvbnxlbnwwfHx8fDE2NzE0MzExODM&amp;ixlib&#x3D;rb-4.0.3&amp;q&#x3D;80&amp;w&#x3D;600 600w"
                                        sizes="(max-width: 472px) 400px, (max-width: 767px) 600px, (min-width: 768px) 400px, 400px"
                                        src="https://images.unsplash.com/photo-1574102289244-69b848408915?crop&#x3D;entropy&amp;cs&#x3D;tinysrgb&amp;fit&#x3D;max&amp;fm&#x3D;jpg&amp;ixid&#x3D;MnwxMTc3M3wwfDF8c2VhcmNofDExfHxvYnNlcnZhdGlvbnxlbnwwfHx8fDE2NzE0MzExODM&amp;ixlib&#x3D;rb-4.0.3&amp;q&#x3D;80&amp;w&#x3D;300" alt="Self-observation is the first step of inner unfolding">
                                </a>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="post-info-wrap">
                                <div class="tag-list">
                                    <a href="/tag/lifestyle/"><span class="tag-accent" style="background: #4d61ff;"></span>Lifestyle</a>
                                </div>
                                <h2 class="post-title h1">
                                    <a href="/self-observation-is-the-first-step-of-inner-unfolding/">Self-observation is the first step of inner unfolding</a>
                                </h2>
                                <div class="post-excerpt">
                                    Mr. Branghton's house is small and inconvenient; though his shop, which takes in all the ground floor, is large and commodious. I believe I told you before, that he is a silver-smith.
                                </div>
                                <div class="post-meta text-s">
                                    <time class="post-date" datetime="2022-05-02">
                                        <svg><use xlink:href="#i-calendar"></use></svg>May 2, 2022
                                    </time>
                                    <span class="read-time">
                                        <svg><use xlink:href="#i-clock"></use></svg>5 min read
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </article>
                <article class="hero-post-card">
                    <div class="row">
                        <div class="col-md-7">
                            <div class="post-img-container">
                                <a href="/the-mind-and-body-are-not-separate-what-affects-one-affects-the-other/" class="post-img-wrap">
                                    <img loading="lazy" srcset="https://images.unsplash.com/photo-1593164842264-854604db2260?crop&#x3D;entropy&amp;cs&#x3D;tinysrgb&amp;fit&#x3D;max&amp;fm&#x3D;jpg&amp;ixid&#x3D;MnwxMTc3M3wwfDF8c2VhcmNofDl8fHlvZ2F8ZW58MHx8fHwxNjcxNDMxNTUx&amp;ixlib&#x3D;rb-4.0.3&amp;q&#x3D;80&amp;w&#x3D;300 300w,
                                            https://images.unsplash.com/photo-1593164842264-854604db2260?crop&#x3D;entropy&amp;cs&#x3D;tinysrgb&amp;fit&#x3D;max&amp;fm&#x3D;jpg&amp;ixid&#x3D;MnwxMTc3M3wwfDF8c2VhcmNofDl8fHlvZ2F8ZW58MHx8fHwxNjcxNDMxNTUx&amp;ixlib&#x3D;rb-4.0.3&amp;q&#x3D;80&amp;w&#x3D;600 600w"
                                        sizes="(max-width: 472px) 400px, (max-width: 767px) 600px, (min-width: 768px) 400px, 400px"
                                        src="https://images.unsplash.com/photo-1593164842264-854604db2260?crop&#x3D;entropy&amp;cs&#x3D;tinysrgb&amp;fit&#x3D;max&amp;fm&#x3D;jpg&amp;ixid&#x3D;MnwxMTc3M3wwfDF8c2VhcmNofDl8fHlvZ2F8ZW58MHx8fHwxNjcxNDMxNTUx&amp;ixlib&#x3D;rb-4.0.3&amp;q&#x3D;80&amp;w&#x3D;300" alt="The mind and body are not separate. what affects one, affects the other">
                                </a>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="post-info-wrap">
                                <div class="tag-list">
                                    <a href="/tag/health/"><span class="tag-accent" style="background: #1dbf2f;"></span>Health</a>
                                </div>
                                <h2 class="post-title h1">
                                    <a href="/the-mind-and-body-are-not-separate-what-affects-one-affects-the-other/">The mind and body are not separate. what affects one, affects the other</a>
                                </h2>
                                <div class="post-excerpt">
                                    His recital put the Captain into an ecstasy; he went from the lady to the gentleman, and from the gentleman to the lady, to enjoy alternately the sight of their distress. He really shouted with pleasure; and, shaking Monsieur Du Bois strenuously by the hand
                                </div>
                                <div class="post-meta text-s">
                                    <time class="post-date" datetime="2022-03-28">
                                        <svg><use xlink:href="#i-calendar"></use></svg>Mar 28, 2022
                                    </time>
                                    <span class="read-time">
                                        <svg><use xlink:href="#i-clock"></use></svg>3 min read
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </article>
                <article class="hero-post-card">
                    <div class="row">
                        <div class="col-md-7">
                            <div class="post-img-container">
                                <a href="/new-tech-innovation-for-low-cost-ocean-cleanup/" class="post-img-wrap">
                                    <img loading="lazy" srcset="https://images.unsplash.com/photo-1437622368342-7a3d73a34c8f?crop&#x3D;entropy&amp;cs&#x3D;tinysrgb&amp;fit&#x3D;max&amp;fm&#x3D;jpg&amp;ixid&#x3D;MnwxMTc3M3wwfDF8c2VhcmNofDE5fHxvY2VhbnxlbnwwfHx8fDE2NzE0MzIyNzg&amp;ixlib&#x3D;rb-4.0.3&amp;q&#x3D;80&amp;w&#x3D;300 300w,
                                            https://images.unsplash.com/photo-1437622368342-7a3d73a34c8f?crop&#x3D;entropy&amp;cs&#x3D;tinysrgb&amp;fit&#x3D;max&amp;fm&#x3D;jpg&amp;ixid&#x3D;MnwxMTc3M3wwfDF8c2VhcmNofDE5fHxvY2VhbnxlbnwwfHx8fDE2NzE0MzIyNzg&amp;ixlib&#x3D;rb-4.0.3&amp;q&#x3D;80&amp;w&#x3D;600 600w"
                                        sizes="(max-width: 472px) 400px, (max-width: 767px) 600px, (min-width: 768px) 400px, 400px"
                                        src="https://images.unsplash.com/photo-1437622368342-7a3d73a34c8f?crop&#x3D;entropy&amp;cs&#x3D;tinysrgb&amp;fit&#x3D;max&amp;fm&#x3D;jpg&amp;ixid&#x3D;MnwxMTc3M3wwfDF8c2VhcmNofDE5fHxvY2VhbnxlbnwwfHx8fDE2NzE0MzIyNzg&amp;ixlib&#x3D;rb-4.0.3&amp;q&#x3D;80&amp;w&#x3D;300" alt="New tech innovation for low cost ocean cleanup">
                                </a>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="post-info-wrap">
                                <div class="tag-list">
                                    <a href="/tag/technology/"><span class="tag-accent" style="background: #f18509;"></span>Technology</a>
                                    <a href="/tag/nature/"><span class="tag-accent" style="background: #fd94ff;"></span>Nature</a>
                                    <a href="/tag/health/"><span class="tag-accent" style="background: #1dbf2f;"></span>Health</a>
                                </div>
                                <h2 class="post-title h1">
                                    <a href="/new-tech-innovation-for-low-cost-ocean-cleanup/">New tech innovation for low cost ocean cleanup</a>
                                </h2>
                                <div class="post-excerpt">
                                    Nearly a year later, in the month of October, London was startled by a crime of singular ferocity and rendered all the more notable by the high position of the victim. The details were few and startling. A maid servant living alone in a house not far from the river.
                                </div>
                                <div class="post-meta text-s">
                                    <time class="post-date" datetime="2021-12-14">
                                        <svg><use xlink:href="#i-calendar"></use></svg>Dec 14, 2021
                                    </time>
                                    <span class="read-time">
                                        <svg><use xlink:href="#i-clock"></use></svg>2 min read
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </article> -->
                <!-- <article class="hero-post-card">
                    <div class="row">
                        <div class="col-md-7">
                            <div class="post-img-container">
                                <a href="/all-the-money-in-the-world-cant-buy-you-back-good-health/" class="post-img-wrap">
                                    <img loading="lazy" srcset="https://images.unsplash.com/photo-1670349148055-e11a0b3be242?crop&#x3D;entropy&amp;cs&#x3D;tinysrgb&amp;fit&#x3D;max&amp;fm&#x3D;jpg&amp;ixid&#x3D;MnwxMTc3M3wxfDF8c2VhcmNofDI5fHxoYXBweXxlbnwwfHx8fDE2NzE0MzI2NjY&amp;ixlib&#x3D;rb-4.0.3&amp;q&#x3D;80&amp;w&#x3D;300 300w,
                                            https://images.unsplash.com/photo-1670349148055-e11a0b3be242?crop&#x3D;entropy&amp;cs&#x3D;tinysrgb&amp;fit&#x3D;max&amp;fm&#x3D;jpg&amp;ixid&#x3D;MnwxMTc3M3wxfDF8c2VhcmNofDI5fHxoYXBweXxlbnwwfHx8fDE2NzE0MzI2NjY&amp;ixlib&#x3D;rb-4.0.3&amp;q&#x3D;80&amp;w&#x3D;600 600w"
                                        sizes="(max-width: 472px) 400px, (max-width: 767px) 600px, (min-width: 768px) 400px, 400px"
                                        src="https://images.unsplash.com/photo-1670349148055-e11a0b3be242?crop&#x3D;entropy&amp;cs&#x3D;tinysrgb&amp;fit&#x3D;max&amp;fm&#x3D;jpg&amp;ixid&#x3D;MnwxMTc3M3wxfDF8c2VhcmNofDI5fHxoYXBweXxlbnwwfHx8fDE2NzE0MzI2NjY&amp;ixlib&#x3D;rb-4.0.3&amp;q&#x3D;80&amp;w&#x3D;300" alt="All the money in the world can&#x27;t buy you back good health">
                                </a>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="post-info-wrap">
                                <div class="tag-list">
                                    <a href="/tag/health/"><span class="tag-accent" style="background: #1dbf2f;"></span>Health</a>
                                    <a href="/tag/lifestyle/"><span class="tag-accent" style="background: #4d61ff;"></span>Lifestyle</a>
                                </div>
                                <h2 class="post-title h1">
                                    <a href="/all-the-money-in-the-world-cant-buy-you-back-good-health/">All the money in the world can&#x27;t buy you back good health</a>
                                </h2>
                                <div class="post-excerpt">
                                    My dear, it never rains but it pours. How true the old proverbs are. Here am I, who shall be twenty in September, and yet I never had a proposal till to-day, not a real proposal, and to-day I have had three. Just fancy! THREE proposals in one day! Isn't
                                </div>
                                <div class="post-meta text-s">
                                    <time class="post-date" datetime="2021-10-09">
                                        <svg><use xlink:href="#i-calendar"></use></svg>Oct 9, 2021
                                    </time>
                                    <span class="read-time">
                                        <svg><use xlink:href="#i-clock"></use></svg>3 min read
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </article> -->
            <!-- </div>
        </div>
    </div> -->
</div>
<div class="container cover home-intro-two">
    <div class="row">
        <div class="col-12">
            <div class="welcome-card has-image">
                <div class="cover-image">
                    <img loading="lazy"
                    srcset="https://images.unsplash.com/photo-1519681393784-d120267933ba?crop&#x3D;entropy&amp;cs&#x3D;tinysrgb&amp;fit&#x3D;max&amp;fm&#x3D;jpg&amp;ixid&#x3D;MnwxMTc3M3wwfDF8c2VhcmNofDZ8fHdhbGxwYXBlcnxlbnwwfHx8fDE2NzE2MDMyNjM&amp;ixlib&#x3D;rb-4.0.3&amp;q&#x3D;80&amp;w&#x3D;300 300w,
                        https://images.unsplash.com/photo-1519681393784-d120267933ba?crop&#x3D;entropy&amp;cs&#x3D;tinysrgb&amp;fit&#x3D;max&amp;fm&#x3D;jpg&amp;ixid&#x3D;MnwxMTc3M3wwfDF8c2VhcmNofDZ8fHdhbGxwYXBlcnxlbnwwfHx8fDE2NzE2MDMyNjM&amp;ixlib&#x3D;rb-4.0.3&amp;q&#x3D;80&amp;w&#x3D;600 600w,
                        https://images.unsplash.com/photo-1519681393784-d120267933ba?crop&#x3D;entropy&amp;cs&#x3D;tinysrgb&amp;fit&#x3D;max&amp;fm&#x3D;jpg&amp;ixid&#x3D;MnwxMTc3M3wwfDF8c2VhcmNofDZ8fHdhbGxwYXBlcnxlbnwwfHx8fDE2NzE2MDMyNjM&amp;ixlib&#x3D;rb-4.0.3&amp;q&#x3D;80&amp;w&#x3D;1200 1200w,
                        https://images.unsplash.com/photo-1519681393784-d120267933ba?crop&#x3D;entropy&amp;cs&#x3D;tinysrgb&amp;fit&#x3D;max&amp;fm&#x3D;jpg&amp;ixid&#x3D;MnwxMTc3M3wwfDF8c2VhcmNofDZ8fHdhbGxwYXBlcnxlbnwwfHx8fDE2NzE2MDMyNjM&amp;ixlib&#x3D;rb-4.0.3&amp;q&#x3D;80&amp;w&#x3D;1400 1400w"
                    sizes="(max-width: 349px) 300px, (max-width: 767px) 600px, (min-width: 768px) 1200px, (min-width: 1290px) 1400px, 1400px"
                    src="https://images.unsplash.com/photo-1519681393784-d120267933ba?crop&#x3D;entropy&amp;cs&#x3D;tinysrgb&amp;fit&#x3D;max&amp;fm&#x3D;jpg&amp;ixid&#x3D;MnwxMTc3M3wwfDF8c2VhcmNofDZ8fHdhbGxwYXBlcnxlbnwwfHx8fDE2NzE2MDMyNjM&amp;ixlib&#x3D;rb-4.0.3&amp;q&#x3D;80&amp;w&#x3D;2000" alt=" cover">
                </div>
                <div class="welcome-card-content-wrap text-center">
                    <h1 class="intro-title">Get healthy food for your amazing mind</h1>
                    <div class="intro-description">
                        Neon is a premium multipurpose Ghost theme suitable for personal, professional, magazine, brand blog and newsletter.
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container cover home-intro-three">
    <div class="welcome-card-personal flex align-center has-image">
        <div class="cover-image">
            <img loading="lazy"
            src="/assets/images/antoine-garcia.jpg?v=7ce521441b" alt=" cover">
        </div>
        <div class="welcome-card-content-wrap">
            <h1 class="intro-title">Hi, I'm Antoine Garcia</h1>
            <div class="intro-description">
                A painter🎨 and sculptor⚒️ based in Paris, France. I try to explore the emotions and expression of minds through my creation.
            </div>
        </div>
    </div>
</div><div class="container">
    <div class="row main-content ">
                    <?php
                    $query = "SELECT * FROM portfolio.articles";
                    $result = mysqli_query($conn, $query);
                    while ($row = mysqli_fetch_array($result)) {
                        //echo "<pre>";print_r($row['category']);die;
                        // $dataArray[$i]['vendor_id'] = $row['id'];
                    
                    ?>
            <div class="col-lg-4 js-demo-content-area">
                <div class="js-post-list-wrap">
                    
                    <article class="post-card flex js-post-card">
                        <div class="post-img-container">
                            <a href="/autumn-is-a-second-spring-when-every-leaf-is-a-flower/" class="post-img-wrap">
                                <img loading="lazy"
                                    sizes="(max-width: 472px) 400px, (max-width: 767px) 600px, (min-width: 768px) 400px, 400px"
                                    src="<?php echo '../personal-blog/uploads/'.$row['blog_image'];?>" alt="<?php echo $row['content'];?>">
                            </a>
                        </div>
                        
                        <div class="post-info-wrap">
                            <div class="tag-list">
                                <a href="/tag/nature/"><span class="tag-accent" style="background: #fd94ff;"></span><?php echo $row['category'];?></a>
                            </div>
                            <!-- <h2 class="post-title">
                                <a href="/autumn-is-a-second-spring-when-every-leaf-is-a-flower/"><?php echo $row['subtitle'];?></a>
                            </h2> -->
                            <div class="post-excerpt">
                                <?php echo charlimit($row['content'], 82); ?>
                            </div>
                            <div class="post-meta text-s">
                                <time class="post-date" datetime="2022-05-02">
                                    <svg><use xlink:href="#i-calendar"></use></svg><?php echo $row['created_at'];?>
                                </time>
                                <span class="read-time">
                                    <svg><use xlink:href="#i-clock"></use></svg><?php echo $row['tags'];?>
                                </span>
                            </div>
                        </div>
                    </article>
                    
                    
                </div>

                <div class="pagination-wrap text-center" id="pagination-wrap">
                    <button class="btn post-load-button" id="load-more"><span>Load more</span></button>
                </div>            
            
            </div>
            <?php } ?>
            <!-- <div class="col-lg-4">
                <div class="sidebar sidebar-sticky">
                    <div class="sidebar-wrap">
                    
                        
                        <div class="widget widget-newsletter widget-newsletter-colored">
                            <h3 class="h2 widget-title text-center">Newsletter</h3>
                        </div>                    
                    </div>
                </div>
            </div>     -->
</div>
</div>
		
        <footer class="site-footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="widget widget-newsletter">
    
    
</div>                <div class="widget">
    <h3 class="h4 widget-title">Follow us</h3>
    <div class="widget-content">
        <div class="social-links flex">
            <a href="https://twitter.com/gbjsolution" class="twitter" aria-label="twitter link"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path fill="none" d="M0 0h24v24H0z"/><path d="M22.162 5.656a8.384 8.384 0 0 1-2.402.658A4.196 4.196 0 0 0 21.6 4c-.82.488-1.719.83-2.656 1.015a4.182 4.182 0 0 0-7.126 3.814 11.874 11.874 0 0 1-8.62-4.37 4.168 4.168 0 0 0-.566 2.103c0 1.45.738 2.731 1.86 3.481a4.168 4.168 0 0 1-1.894-.523v.052a4.185 4.185 0 0 0 3.355 4.101 4.21 4.21 0 0 1-1.89.072A4.185 4.185 0 0 0 7.97 16.65a8.394 8.394 0 0 1-6.191 1.732 11.83 11.83 0 0 0 6.41 1.88c7.693 0 11.9-6.373 11.9-11.9 0-.18-.005-.362-.013-.54a8.496 8.496 0 0 0 2.087-2.165z"/></svg></a>
            <a href="https://www.facebook.com/gbjsolution" class="facebook" aria-label="facebook link"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path fill="none" d="M0 0h24v24H0z"/><path d="M14 13.5h2.5l1-4H14v-2c0-1.03 0-2 2-2h1.5V2.14c-.326-.043-1.557-.14-2.857-.14C11.928 2 10 3.657 10 6.7v2.8H7v4h3V22h4v-8.5z"/></svg></a>
            <a href="#" class="linkedin" aria-label="linkedin link"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path fill="none" d="M0 0h24v24H0z"/><path d="M6.94 5a2 2 0 1 1-4-.002 2 2 0 0 1 4 .002zM7 8.48H3V21h4V8.48zm6.32 0H9.34V21h3.94v-6.57c0-3.66 4.77-4 4.77 0V21H22v-7.93c0-6.17-7.06-5.94-8.72-2.91l.04-1.68z"/></svg></a>
            <a href="#" class="instagram" aria-label="instagram link"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path fill="none" d="M0 0h24v24H0z"/><path d="M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6zm0-2a5 5 0 1 1 0 10 5 5 0 0 1 0-10zm6.5-.25a1.25 1.25 0 0 1-2.5 0 1.25 1.25 0 0 1 2.5 0zM12 4c-2.474 0-2.878.007-4.029.058-.784.037-1.31.142-1.798.332-.434.168-.747.369-1.08.703a2.89 2.89 0 0 0-.704 1.08c-.19.49-.295 1.015-.331 1.798C4.006 9.075 4 9.461 4 12c0 2.474.007 2.878.058 4.029.037.783.142 1.31.331 1.797.17.435.37.748.702 1.08.337.336.65.537 1.08.703.494.191 1.02.297 1.8.333C9.075 19.994 9.461 20 12 20c2.474 0 2.878-.007 4.029-.058.782-.037 1.309-.142 1.797-.331.433-.169.748-.37 1.08-.702.337-.337.538-.65.704-1.08.19-.493.296-1.02.332-1.8.052-1.104.058-1.49.058-4.029 0-2.474-.007-2.878-.058-4.029-.037-.782-.142-1.31-.332-1.798a2.911 2.911 0 0 0-.703-1.08 2.884 2.884 0 0 0-1.08-.704c-.49-.19-1.016-.295-1.798-.331C14.925 4.006 14.539 4 12 4zm0-2c2.717 0 3.056.01 4.122.06 1.065.05 1.79.217 2.428.465.66.254 1.216.598 1.772 1.153a4.908 4.908 0 0 1 1.153 1.772c.247.637.415 1.363.465 2.428.047 1.066.06 1.405.06 4.122 0 2.717-.01 3.056-.06 4.122-.05 1.065-.218 1.79-.465 2.428a4.883 4.883 0 0 1-1.153 1.772 4.915 4.915 0 0 1-1.772 1.153c-.637.247-1.363.415-2.428.465-1.066.047-1.405.06-4.122.06-2.717 0-3.056-.01-4.122-.06-1.065-.05-1.79-.218-2.428-.465a4.89 4.89 0 0 1-1.772-1.153 4.904 4.904 0 0 1-1.153-1.772c-.248-.637-.415-1.363-.465-2.428C2.013 15.056 2 14.717 2 12c0-2.717.01-3.056.06-4.122.05-1.066.217-1.79.465-2.428a4.88 4.88 0 0 1 1.153-1.772A4.897 4.897 0 0 1 5.45 2.525c.638-.248 1.362-.415 2.428-.465C8.944 2.013 9.283 2 12 2z"/></svg></a>
            <a href="#" class="github" aria-label="github link"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path fill="none" d="M0 0h24v24H0z"/><path d="M12 2C6.475 2 2 6.475 2 12a9.994 9.994 0 0 0 6.838 9.488c.5.087.687-.213.687-.476 0-.237-.013-1.024-.013-1.862-2.512.463-3.162-.612-3.362-1.175-.113-.288-.6-1.175-1.025-1.413-.35-.187-.85-.65-.013-.662.788-.013 1.35.725 1.538 1.025.9 1.512 2.338 1.087 2.912.825.088-.65.35-1.087.638-1.337-2.225-.25-4.55-1.113-4.55-4.938 0-1.088.387-1.987 1.025-2.688-.1-.25-.45-1.275.1-2.65 0 0 .837-.262 2.75 1.026a9.28 9.28 0 0 1 2.5-.338c.85 0 1.7.112 2.5.337 1.912-1.3 2.75-1.024 2.75-1.024.55 1.375.2 2.4.1 2.65.637.7 1.025 1.587 1.025 2.687 0 3.838-2.337 4.688-4.562 4.938.362.312.675.912.675 1.85 0 1.337-.013 2.412-.013 2.75 0 .262.188.574.688.474A10.016 10.016 0 0 0 22 12c0-5.525-4.475-10-10-10z"/></svg></a>
        </div>
    </div>
</div>            </div>
            
            
        </div>
    </div>
    <div class="container flex justify-space-between footer-bottom">
        <div class="copyright">
            <div class="copyright">
    &copy; 2023 <a href="https://neon.gbjsolution.com">Neon</a> - All right Reserved. Proudly Published with <a href="https://ghost.org?via=biswajit48">Ghost</a>
</div>        </div>
        <div class="back-to-top">
            <button class="btn-link js-scroll-top"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path fill="none" d="M0 0h24v24H0z"/><path d="M13 7.828V20h-2V7.828l-5.364 5.364-1.414-1.414L12 4l7.778 7.778-1.414 1.414L13 7.828z"/></svg>Back to top</button>
        </div>
    </div>
</footer>		</div>
		<script>
            var nextPage = '2';
            var totalPages = '3';
        </script>
		<script src="/blog/assets/js/plugin/tiny-slider.js?v=7ce521441b"></script>
<script>
     let slider = tns({
        container: '.featured-slider',
        items: 1,
        slideBy: 'page',
        controlsPosition: 'bottom',
        controlsText: ['<svg><use xlink:href="#i-arrow-left"></use></svg>', '<svg><use xlink:href="#i-arrow-right"></use></svg>'],
        nav: false,
        mouseDrag: true
    });
</script>

		<script src="/blog/assets/js/app.bundle.min.js?v=7ce521441b"></script>
        <script src="/blog/assets/js/plugin/prism.js"></script>
        <link rel="stylesheet" href="/blog/assets/css/mystyle.css">

<div class="settings-panel closed" id="setting-panel">
    
    
    <div class="settings-wrap">
        <div class="setting-section">
            <div class="setting-section-title">
                <label for="intro_type">Home intro style</label>
            </div>
            <select name="intro_type" id="intro_type">
				<option value="one">Style 1 - featured posts slider</option>
				<option value="two">Style 2 - tilte and description</option>
				<option value="three">Style 3 - personal introduction</option>
			</select>
        </div>
        <div class="setting-section">
            <div class="setting-section-title">
                <label for="nav_type">Nav style</label>
            </div>
            <select name="nav_type" id="nav_type">
				<option value="normal">Normal</option>
				<option value="sticky">Sticky</option>
                <option value="sticky-hide">Sticky Hide</option>
			</select>
        </div>
        <div class="setting-section setting-type-toggle">
            <label for="hide_sidebar">Hide sidebar</label>
            <input type="checkbox" id="hide_sidebar" name="hide_sidebar" class="toggle-switch">
        </div>
        <div class="setting-section setting-type-toggle">
            <label for="rounded_corner">Disable rounded corner</label>
            <input type="checkbox" id="rounded_corner" name="rounded_corner" class="toggle-switch">
        </div>
        <div class="setting-section setting-type-toggle">
            <div class="">
                <label for="accent_color">Choose accent color</label>
            </div>
            <input type="color" value="#FB2576" id="accent_color" class="color-input">
        </div>
        <div class="setting-section setting-type-toggle">
            <div class="">
                <label for="light_bg_color">Choose Light theme background color</label>
            </div>
            <input type="color" value="#F9F9FF" id="light_bg_color" class="color-input">
        </div>
        <button class="btn btn-sm btn-block btn-icon btn-bordered" style="margin-bottom:16px" onclick="reset();"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M18.885 3.515c-4.617-4.618-12.056-4.676-16.756-.195l-2.129-2.258v7.938h7.484l-2.066-2.191c2.82-2.706 7.297-2.676 10.073.1 4.341 4.341 1.737 12.291-5.491 12.291v4.8c3.708 0 6.614-1.244 8.885-3.515 4.686-4.686 4.686-12.284 0-16.97z"/></svg><span>Reset all settings</span></button>
        <a href="https://1.envato.market/neon-ghost" class="btn btn-block btn-icon btn-sm"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M10 20.5c0 .829-.672 1.5-1.5 1.5s-1.5-.671-1.5-1.5c0-.828.672-1.5 1.5-1.5s1.5.672 1.5 1.5zm3.5-1.5c-.828 0-1.5.671-1.5 1.5s.672 1.5 1.5 1.5 1.5-.671 1.5-1.5c0-.828-.672-1.5-1.5-1.5zm6.304-17l-3.431 14h-2.102l2.541-11h-16.812l4.615 13h13.239l3.474-14h2.178l.494-2h-4.196z"/></svg><span>Get this theme</span></a>
    </div>
</div>
<?php
function charlimit($string, $limit) {

    return substr($string, 0, $limit) . (strlen($string) > $limit ? "..." : '');
}
?>

<script>
    const root = document.querySelector(':root');
    const body = document.body;
    const settingToggle = document.getElementById('setting-panel-toggle');
    settingToggle.addEventListener('click', function(e) {
        document.getElementById('setting-panel').classList.toggle('closed');
    })
    /* rounded corner */
    const savedRoundedCorner = localStorage.getItem('rounded-corner');
    const RoundedCornerOption = document.getElementById('rounded_corner');
    if(savedRoundedCorner === 'true') {
        RoundedCornerOption.checked = savedRoundedCorner;
        body.classList.add('no-rounded');
    }
    RoundedCornerOption.addEventListener('change', function() {
        localStorage.setItem('rounded-corner', this.checked);
        if (this.checked) {
            body.classList.add('no-rounded');
        } else {
            body.classList.remove('no-rounded');
        }
    });
    
    /* sidebar*/
    const savedSidebar = localStorage.getItem('sidebar');
    const savedSidebarOption = document.getElementById('hide_sidebar');
    if(savedSidebar === 'true') {
        console.log(savedSidebar);
        savedSidebarOption.checked = savedSidebar;
        handleSidebar(savedSidebar);
    }
    savedSidebarOption.addEventListener('change', function() {
        localStorage.setItem('sidebar', this.checked);
        handleSidebar(this.checked.toString())
    });
    function handleSidebar(option) {
        const contentArea = document.querySelector('.js-demo-content-area');
        const sidebar = document.querySelector('.sidebar');
        if(sidebar) {
            if(option === 'true') {
                sidebar.classList.add('hidden');
                contentArea.classList.remove('col-lg-8');
                if(contentArea.classList.contains('demo-vertical')) {
                   contentArea.classList.add('col-lg-12');
                } else {
                contentArea.classList.add('col-lg-9');
                contentArea.classList.add('mx-auto');
                }
                let posts= document.querySelectorAll('.col-md-6.js-post-card');
                                                     console.log(posts);
                posts.forEach(function(i){
                    i.classList.add('col-lg-4');
                    i.classList.remove('col-lg-6');
                });
            } else {
                sidebar.classList.remove('hidden');
                contentArea.classList.add('col-lg-8');
                if(contentArea.classList.contains('demo-vertical')) {
                   contentArea.classList.remove('col-lg-12');
            	} else {
                	contentArea.classList.remove('col-lg-9');
                	contentArea.classList.remove('mx-auto');
                }
                let posts= document.querySelectorAll('.col-md-6.js-post-card');
                posts.forEach(function(i){
                    i.classList.add('col-lg-6');
                    i.classList.remove('col-lg-4');
                });
            }
        }
    }
/* nav-type */
    const savedNavType = localStorage.getItem('nav-style');
    if(savedNavType) {
        document.getElementById('nav_type').value = savedNavType;
        body.setAttribute('data-nav', savedNavType);
    }
    const navTypeOption = document.getElementById('nav_type');
    navTypeOption.addEventListener('change', function() {
        const navType = this.value;
        body.setAttribute('data-nav', navType);
        localStorage.setItem('nav-style', navType);
        handleNav();
    });
    /* home intro section */
    const savedIntroType = localStorage.getItem('intro-style');
    const introTypeOption = document.getElementById('intro_type');
    if(savedIntroType) {
        introTypeOption.value = savedIntroType;
        document.documentElement.setAttribute('data-intro', savedIntroType);
    }
    introTypeOption.addEventListener('change', function() {
        const introType = this.value;
        document.documentElement.setAttribute('data-intro', introType);
        localStorage.setItem('intro-style', introType);
    });
    function initNav() {
        CustomThrottle(handleNav(), 50);
    }
    function handleNav() {
        var scroll = 1;
        var navType = document.body.getAttribute('data-nav');
        var header = document.querySelector('.site-header');
        if(typeof(header) !== undefined && header !== null) {
            if ( navType === 'sticky') {
                window.addEventListener('scroll', CustomThrottle(function(){
                    var currScroll = window.pageYOffset;
                    if (currScroll > 1) {
                        header.classList.add("small");
                    } else {
                        header.classList.remove("small");
                    };
                }, 50));
            } else if (navType === 'sticky-hide') {
                window.addEventListener('scroll', CustomThrottle(function(){
                    var currScroll = window.pageYOffset;
                    if (currScroll > 1) {
                        header.classList.add("small");
                    } else {
                        header.classList.remove("small");
                    };
                    if ( currScroll <= scroll) {
                        header.classList.add("show");
                        header.classList.remove("hide");
                        scroll = currScroll;
                    } else {
                        header.classList.remove("show");
                        header.classList.add("hide");
                        scroll = currScroll;
                    }
                    if (currScroll == 0) {
                        header.classList.remove("hide");
                        header.classList.remove("show");
                        header.classList.remove("sticky");
                    }
                }, 50));
            } else {
                header.classList.remove("hide");
                header.classList.remove("show");
                header.classList.remove("sticky");
            }
        }
    }
    function CustomThrottle(func, limit) {
        var lastFunc, lastRan;
        return function () {
            var context = this, args = arguments;
            if (!lastRan) {
                func.apply(context, args)
                lastRan = Date.now()
            } else {
                clearTimeout(lastFunc)
                lastFunc = setTimeout(function () {
                    if ((Date.now() - lastRan) >= limit) {
                        func.apply(context, args)
                        lastRan = Date.now()
                    }
                }, limit - (Date.now() - lastRan))
            }
        }
    }
	/* accent color changing */
    const savedAccentColor = localStorage.getItem('accent-color');
    const accentColorOption = document.getElementById('accent_color');
    if(savedAccentColor) {
        accentColorOption.value = savedAccentColor;
        root.style.setProperty("--theme-color", savedAccentColor);
    }
    accentColorOption.addEventListener('input', function() {
        const selectedAccentColor = this.value;
        root.style.setProperty("--theme-color", selectedAccentColor);
        localStorage.setItem('accent-color', selectedAccentColor);
    });
    /* light background color changing */
    const savedLightBgColor = localStorage.getItem('light-bg-color');
    const lightBgColorOption = document.getElementById('light_bg_color');
    if(savedLightBgColor) {
        lightBgColorOption.value = savedLightBgColor;
        body.style.setProperty("--body-custom-background-color", savedLightBgColor);
    }
    lightBgColorOption.addEventListener('input', function() {
        const selectedLightBgColor = this.value;
        body.style.setProperty("--body-custom-background-color", selectedLightBgColor);
        localStorage.setItem('light-bg-color', selectedLightBgColor);
    });
    function reset() {
        localStorage.clear();
        location.reload();
    }
</script>
	</body>
</html>